<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            background: url('https://c4.wallpaperflare.com/wallpaper/116/649/220/affection-baby-birth-black-and-white-wallpaper-preview.jpg') no-repeat center center fixed;
            background-size: cover;

        }
        .container {
            max-width: 700px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        .button-container {
            text-align: center;
        }
        .button-container .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #5cb85c;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin: 10px;
        }
        .button-container .button:hover {
            background-color: #5cb85c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Birth Certificate Portal</h1>
        <div class="button-container">
            <a href="signup.php" class="button">Signup</a>
            <a href="verify_certificate.php" class="button">Certification Verification</a>
            <a href="admin_login.php" target="_blank" class="button">Admin Login</a>
        </div>
    </div>
</body>
</html>