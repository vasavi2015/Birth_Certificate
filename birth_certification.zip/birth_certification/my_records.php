<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];
$user_data = [];
$transaction_data = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $new_email = $_POST['email'];
    $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $new_gender = $_POST['gender'];
    $new_contact = $_POST['contact'];

    $update_sql = "UPDATE users SET email=?, password=?, gender=?, contact=? WHERE id=?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssssi", $new_email, $new_password, $new_gender, $new_contact, $user_id);

    if ($update_stmt->execute()) {
        $_SESSION['username'] = $new_email;
        echo "<script>alert('Details updated successfully!');</script>";
    } else {
        echo "<script>alert('Failed to update details.');</script>";
    }

    $update_stmt->close();
}

$user_sql = "SELECT username, email, gender, contact FROM users WHERE id=?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_stmt->bind_result($username, $email, $gender, $contact);
$user_stmt->fetch();
$user_stmt->close();

$transaction_sql = "SELECT transaction_id, application_id, amount, payment_date FROM transactions WHERE application_id=?";

$transaction_stmt = $conn->prepare($transaction_sql);
$transaction_stmt->bind_param("i", $user_id);
$transaction_stmt->execute();
$transaction_result = $transaction_stmt->get_result();
while ($row = $transaction_result->fetch_assoc()) {
    $transaction_data[] = $row;
}
$transaction_stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin: 0;
            padding: 20px;
        }
        table {
            width: 80%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        button {
            padding: 10px;
            margin-top: 10px;
            margin-left: 100px;
            cursor: pointer;
            border-radius: 5px;
            border: none;
            background-color: #4CAF50;
            color: white;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>My Profile</h1>
    <h2>Update Your Details</h2>
    <form action="my_records.php" method="post">
        <table>
            <tbody>
                <tr>
                    <th>Label</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" disabled></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required></td>
                </tr>
                <tr>
                    <td>New Password:</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td>Gender:</td>
                    <td><input type="text" name="gender" value="<?php echo htmlspecialchars($gender); ?>" required></td>
                </tr>
                <tr>
                    <td>Contact:</td>
                    <td><input type="text" name="contact" value="<?php echo htmlspecialchars($contact); ?>" required></td>
                </tr>
            </tbody>
        </table>
        <button type="submit" name="update">Update</button>
    </form>
</body>
</html>
