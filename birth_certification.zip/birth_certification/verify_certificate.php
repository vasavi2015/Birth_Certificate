<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize $application variable
$application = null;

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $registration_number = $_POST['registration_number'];
    $parent_aadhaar = $_POST['parent_aadhaar'];

    // Validate inputs
    if (empty($registration_number) || empty($parent_aadhaar)) {
        $status = "Please enter both registration number and parent Aadhaar number.";
    } else {
        // Check if the registration number exists in applications table
        $sql = "SELECT * FROM applications WHERE id = ? AND parent_aadhar = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $registration_number, $parent_aadhaar);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $application = $result->fetch_assoc();
            $status = "Verification successful. Status: " . $application['status'];
        } else {
            $status = "No record found with provided registration number and parent Aadhaar number.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Verification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            padding: 20px;
            background: url('https://i.pinimg.com/564x/be/12/37/be12376948b2cf6045caba0f869388af.jpg') no-repeat center center fixed;
            background-size: cover;

        }

        h1 {
            color: #4CAF50;
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="submit"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .status {
            margin-top: 20px;
            font-size: 16px;
            color: #333;
        }

        .download-form {
            margin-top: 20px;
        }
        
        .download-button {
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 16px;
            width: 100%;
        }
        
        .download-button:hover {
            background-color: #45a049;
        }

        .home-button {
            margin-top: 20px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 16px;
            max-width: 55px;
            width: 100%;
            text-align: center;
            display: inline-block;
            text-decoration: none;
        }
        
        .home-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Certificate Verification</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="registration_number">Registration Number:</label>
        <input type="text" id="registration_number" name="registration_number" required>
        <label for="parent_aadhaar">Parent Aadhaar Number:</label>
        <input type="text" id="parent_aadhaar" name="parent_aadhaar" required>
        <input type="submit" value="Submit">
    </form>
    <?php if(isset($status)): ?>
        <p><?php echo $status; ?></p>
        <?php if(isset($application) && $application['status'] == "Accepted"): ?>
            <form action="generate_pdf.php" method="post" target="_blank">
                <input type="hidden" name="id" value="<?php echo $application['id']; ?>">
                <input type="hidden" name="parent_aadhaar" value="<?php echo $parent_aadhaar; ?>">
                <input type="submit" value="Download Birth Certificate" class="download-button">
            </form>
        <?php endif; ?>
    <?php endif; ?>
    <a href="user_portal.php" class="home-button">Home</a>
</body>
</html>
