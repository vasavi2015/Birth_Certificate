<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Success</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: url(https://i.pinimg.com/564x/81/54/41/8154419fcb5615d870c9be12d2400064.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            text-align: center;
            padding: 50px;
        }
        
        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            margin-bottom: 30px;
        }

        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin: 10px;
        }

        button:hover {
            background-color: #45a049;
        }

        .button-container {
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
    <h1>Registration Success</h1>
    <p>Your registration number is: <?php echo htmlspecialchars($_GET['reg_number']); ?></p>
    <div class="button-container">
        <a href="user_portal.php"><button>Home</button></a>
        <a href="home.php"><button>Application</button></a>
    </div>
</body>
</html>