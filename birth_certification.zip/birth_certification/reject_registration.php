<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reject Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: url('https://static.vecteezy.com/system/resources/thumbnails/002/626/834/small/light-red-blurred-background-vector.jpg');
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            color: #A52A2A;
            margin-bottom: 20px;
        }

        p {
            color: black;
            margin-bottom: 20px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Reject Registration</h1>
        <?php
        session_start();

        // Check if admin is logged in, redirect to login page if not
        if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
            header("Location: admin_login.php");
            exit;
        }

        // Check if registration ID is provided in the URL
        if (!isset($_POST['registration_id']) || empty($_POST['registration_id'])) {
            header("Location: admin_home.php");
            exit;
        }

        // Database connection
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "birth_certification";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Update registration status to 'Rejected'
        $registration_id = $_POST['registration_id'];
        $sql = "UPDATE applications SET status = 'Rejected' WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $registration_id);

        if ($stmt->execute()) {
            echo "<p>Registration rejected successfully!</p>";
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }

        $stmt->close();
        $conn->close();
        ?>

        <button onclick="window.location.href = 'admin_home.php';">Go back to Home page</button>
    </div>
</body>
</html>