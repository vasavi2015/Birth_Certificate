<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $email = $password = $gender = $contact = "";
$usernameErr = $emailErr = $passwordErr = $genderErr = $contactErr = "";
$formIsValid = true;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate inputs
    if (empty($_POST["username"])) {
        $usernameErr = "Username is required";
        $formIsValid = false;
    } else {
        $username = test_input($_POST["username"]);
    }

    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
        $formIsValid = false;
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
            $formIsValid = false;
        }
    }

    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
        $formIsValid = false;
    } else {
        $password = test_input($_POST["password"]);
        if (strlen($password) < 6) {
            $passwordErr = "Password must be at least 6 characters long";
            $formIsValid = false;
        }
    }

    if (empty($_POST["gender"])) {
        $genderErr = "Gender is required";
        $formIsValid = false;
    } else {
        $gender = test_input($_POST["gender"]);
    }

    if (empty($_POST["contact"])) {
        $contactErr = "Contact is required";
        $formIsValid = false;
    } else {
        $contact = test_input($_POST["contact"]);
        if (!preg_match("/^[0-9]{10}$/", $contact)) {
            $contactErr = "Contact must be exactly 10 digits";
            $formIsValid = false;
        }
    }

    // Check if the email already exists
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $emailErr = "User with this email already exists";
        $formIsValid = false;
    }
    $stmt->close();

    // If the form is valid, proceed with database insertion
    if ($formIsValid) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, gender, contact) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $email, $hashed_password, $gender, $contact);
        
        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href='login.php';</script>";
            exit();
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }

        $stmt->close();
    }
}

$conn->close();

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <style>
        /* CSS styles */
        body {
            font-family: Arial, sans-serif;
            background: url('https://i.pinimg.com/564x/10/7b/e0/107be00dfcd1a5bf3bfc24ad16036aa8.jpg') no-repeat center center fixed;
            background-position: calc(50% - 220px) center; /* Move the background image 50px to the right */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #b7b7b7;
            padding: 50px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            height: 520px;
            width: 450px;
            position: relative;
            left: 360px; /* Move the signup box 50px to the right */
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: calc(100% - 10px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .error {
            color: red;
            font-size: 0.8em;
        }

        button[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #45a049;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .radio-group {
            display: flex;
            flex-direction: row; /* Change to row */
            align-items: center; /* Align items vertically */
        }

        .radio-group input[type="radio"] {
             margin-right: 20px;
             margin-left: 20px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Signup Form</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="username">Enter your full name:</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                <span class="error"><?php echo $usernameErr; ?></span>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                <span class="error"><?php echo $emailErr; ?></span>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <span class="error"><?php echo $passwordErr; ?></span>
            </div>

            <div class="form-group radio-group">
                <label for="gender">Gender:</label>
                <input type="radio" id="male" name="gender" value="Male" <?php if ($gender == "Male") echo "checked"; ?> required>
                <label for="male">Male</label>
                <input type="radio" id="female" name="gender" value="Female" <?php if ($gender == "Female") echo "checked"; ?> required>
                <label for="female">Female</label>
                <span class="error"><?php echo $genderErr; ?></span><br><br>
            </div>

            <div class="form-group">
                <label for="contact">Contact:</label>
                <input type="text" id="contact" name="contact" value="<?php echo htmlspecialchars($contact); ?>" required>
                <span class="error"><?php echo $contactErr; ?></span>
            </div>

            <button type="submit">Signup</button>

            <p>Already have an account? <a href="login.php">Login here</a></p>
        </form>
    </div>
</body>
</html>
