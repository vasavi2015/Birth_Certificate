<?php
session_start();

// Check if admin is logged in, redirect to login page if not
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

// Check if registration ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: admin_home.php");
    exit;
}

$registration_id = $_GET['id'];

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch registration details
$sql = "SELECT * FROM applications WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $registration_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Registration not found";
    exit;
}

$row = $result->fetch_assoc();

// Close statement and connection
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('https://cdn.wallpapersafari.com/41/79/jYM7Zu.jpg');
            margin: 0;
            margin-top: 35px;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 600px; /* Decreased width */
            width: 100%;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        button {
            background-color: #5cb85c;
            color: #fff;
            border: none;
            border-radius: 8px; /* Increased button radius */
            padding: 12px 24px; /* Increased button padding */
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #5cb85c;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .home-button {
            background-color: #2E8B57;
        }

        .home-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registration Details</h1>
        <table border="1">
            <tr>
                <th>Field</th> <!-- Changed to 'Field' -->
                <th>Particulars</th> <!-- Changed to 'Particulars' -->
            </tr>
            <tr>
                <td>Child's Name:</td>
                <td><?php echo $row['child_name']; ?></td>
            </tr>
            <tr>
                <td>Date of Birth:</td>
                <td><?php echo $row['birth_date']; ?></td>
            </tr>
            <tr>
                <td>Place of Birth:</td>
                <td><?php echo $row['birth_place']; ?></td>
            </tr>
            <tr>
                <td>Gender:</td>
                <td><?php echo $row['gender']; ?></td>
            </tr>
            <tr>
                <td>Mother's Full Name:</td>
                <td><?php echo $row['mother_name']; ?></td>
            </tr>
            <tr>
                <td>Father's Full Name:</td>
                <td><?php echo $row['father_name']; ?></td>
            </tr>
            <tr>
                <td>Parent's Aadhar Number:</td>
                <td><?php echo $row['parent_aadhar']; ?></td>
            </tr>
            <tr>
                <td>Proof of Birth:</td>
                <td><a href="uploads/<?php echo $row['proof_of_birth']; ?>" target="_blank"><?php echo $row['proof_of_birth']; ?></a></td>
            </tr>
            <tr>
                <td>Parent's Identification:</td>
                <td><?php 
                    $parent_id_files = explode(',', $row['parent_id']);
                    foreach ($parent_id_files as $file) {
                        echo "<a href='uploads/$file' target='_blank'>$file</a><br>";
                    }
                ?></td>
            </tr>
            <tr>
                <td>Marital Status of Parents:</td>
                <td><?php echo $row['marital_status']; ?></td>
            </tr>
            <tr>
                <td>Address:</td>
                <td><?php echo $row['address']; ?></td>
            </tr>
            <tr>
                <td>Phone Number:</td>
                <td><?php echo $row['phone']; ?></td>
            </tr>
            <tr>
                <td>Email Address:</td>
                <td><?php echo $row['email']; ?></td>
            </tr>
            <tr>
                <td>Witness Information:</td>
                <td><?php echo $row['witness_info']; ?></td>
            </tr>
        </table>

        <!-- Home button -->
        <div class="button-container">
            <form action="admin_home.php">
                <button class="home-button">Home</button>
            </form>

            <!-- Accept and Reject buttons -->
            <form action="accept_registration.php" method="post">
                <input type="hidden" name="registration_id" value="<?php echo $registration_id; ?>">
                <button type="submit" name="action" value="accept">Accept</button>
            </form>

            <form action="reject_registration.php" method="post">
                <input type="hidden" name="registration_id" value="<?php echo $registration_id; ?>">
                <button type="submit" name="action" value="reject">Reject</button>
            </form>
        </div>
    </div>
</body>
</html>
