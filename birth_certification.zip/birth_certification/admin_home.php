<?php
session_start();

// Check if admin is logged in, redirect to login page if not
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch new registrations
$sql = "SELECT * FROM applications WHERE status = 'Pending'";
$result = $conn->query($sql);

// Fetch accepted registrations
$sql_accepted = "SELECT * FROM applications WHERE status = 'Accepted'";
$result_accepted = $conn->query($sql_accepted);
$count_accepted = $result_accepted->num_rows;

// Fetch rejected registrations
$sql_rejected = "SELECT * FROM applications WHERE status = 'Rejected'";
$result_rejected = $conn->query($sql_rejected);
$count_rejected = $result_rejected->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: url(https://cdn.wallpapersafari.com/41/79/jYM7Zu.jpg);
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative; /* Position relative for absolute positioning */
        }
        h1, h2 {
            color: #333;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        .count {
            font-weight: bold;
            margin-right: 10px;
        }
        .action-links {
            text-align: center; /* Center align for action links */
        }
        .action-links a {
            display: inline-block;
            margin-right: 10px;
            text-decoration: none;
            padding: 8px 16px;
            background-color: #5cb85c;
            color: #fff;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .action-links a:hover {
            background-color: #5cb85c;
        }
        .logout {
            position: absolute;
            bottom: 20px;
            right: 20px;
            padding: 8px 16px;
            background-color: #dc3545;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .logout i {
            margin-right: 5px;
        }
        .logout:hover {
            background-color: #c82333;
        }
        .view-button {
            display: inline-block;
            padding: 8px 16px;
            background-color: #5cb85c;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
        }
        .view-button:hover {
            background-color: #5cb85c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>New Registrations</h1>
        <table>
            <tr>
                <th>Child's Name</th>
                <th>Date of Birth</th>
                <th>Action</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["child_name"] . "</td>";
                    echo "<td>" . $row["birth_date"] . "</td>";
                    echo "<td><a href='view_registration.php?id=" . $row["id"] . "' class='view-button'>View</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No new registrations</td></tr>";
            }
            ?>
        </table>

        <div class="action-links">
            <h2>Accepted</h2>
            <span class="count"><?php echo $count_accepted; ?></span>
            <a href="view_accepted.php">View</a> <!-- View button for accepted registrations -->
        </div>

        <div class="action-links">
            <h2>Rejected</h2>
            <span class="count"><?php echo $count_rejected; ?></span>
            <a href="view_rejected.php">View</a> <!-- View button for rejected registrations -->
        </div>

        <button class="logout" onclick="logout()"><i class="fa fa-sign-out"></i>Logout</button>
    </div>

    <script>
        function logout() {
            window.location.href = 'logout.php';
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>