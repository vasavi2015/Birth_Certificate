<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $childName = $_POST['childName'];
    $birthDate = $_POST['birthDate'];
    $birthPlace = $_POST['birthPlace'];
    $gender = $_POST['gender'];
    $motherName = $_POST['motherName'];
    $fatherName = $_POST['fatherName'];
    $parentAadhar = $_POST['parentAadhar'];
    $maritalStatus = $_POST['maritalStatus'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $witnessInfo = $_POST['witnessInfo'];

    $proofOfBirth = $_FILES['proofOfBirth']['name'];
    $parentID = implode(',', $_FILES['parentID']['name']);

    $target_dir = "uploads/";
    move_uploaded_file($_FILES['proofOfBirth']['tmp_name'], $target_dir . basename($_FILES['proofOfBirth']['name']));
    foreach ($_FILES['parentID']['tmp_name'] as $key => $tmp_name) {
        move_uploaded_file($tmp_name, $target_dir . basename($_FILES['parentID']['name'][$key]));
    }

    // Assuming the payment is successful
    $payment_successful = true; // Change this based on actual payment result

    if ($payment_successful) {
        // Insert application data into database
        $stmt = $conn->prepare("INSERT INTO applications (child_name, birth_date, birth_place, gender, mother_name, father_name, parent_aadhar, proof_of_birth, parent_id, marital_status, address, phone, email, witness_info) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssssssss", $childName, $birthDate, $birthPlace, $gender, $motherName, $fatherName, $parentAadhar, $proofOfBirth, $parentID, $maritalStatus, $address, $phone, $email, $witnessInfo);

        if ($stmt->execute()) {
            $application_id = $stmt->insert_id;

            // Save transaction record in the database
            $payment_amount = 25.00; // Change this to the actual payment amount
            $stmt_payment = $conn->prepare("INSERT INTO transactions (application_id, amount, payment_date) VALUES (?, ?, NOW())");
            $stmt_payment->bind_param("id", $application_id, $payment_amount);
            $stmt_payment->execute();
            $stmt_payment->close();

            echo '<script>alert("Payment Successful. Redirecting to Registration Success Page."); window.location.href = "registration_success.php?reg_number=' . $application_id . '";</script>';
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        // Handle payment failure
        echo '<script>alert("Payment Failed. Please try again.");</script>';
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BirthCertify - Birth Certificate Application</title>
    <style>
        body, h1, form, input, label, button {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            background-image: url(https://cdn.wallpapersafari.com/41/79/jYM7Zu.jpg);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            margin-top: 750px;
            background-color: #fff;
            padding: 20px 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            text-align: center;
            position: relative;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
            font-size: 1.5rem;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"], input[type="date"], input[type="file"], input[type="tel"], input[type="email"] {
            width: calc(100% - 12px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
            display: block;
        }

        input[type="radio"] {
            margin-right: 10px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            margin-top: 20px;
        }

        button:hover {
            background-color: #45a049;
        }

        .address-group {
            display: flex;
            gap: 10px;
        }

        .address-group .form-group {
            flex: 1;
        }

        .logout-button {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 10px 20px;
            background-color: #f44336;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }

        .logout-button:hover {
            background-color: #d32f2f;
        }

        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }

            h1 {
                font-size: 1.2rem;
            }

            .address-group {
                flex-direction: column;
            }
        }
        /* Your CSS styles */
    </style>
</head>
<body>
    <div class="container">
        <a href="logout.php" class="logout-button">Logout</a>
        <form id="birthForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
            <h2>Child's Information</h2>
            <div class="form-group">
                <label for="childName">Child's Full Name:</label>
                <input type="text" id="childName" name="childName" required>
            </div>
            <div class="form-group">
                <label for="birthDate">Date of Birth:</label>
                <input type="date" id="birthDate" name="birthDate" required>
            </div>
            <div class="form-group">
                <label for="birthPlace">Place of Birth:</label>
                <input type="text" id="birthPlace" name="birthPlace" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label>
                <input type="radio" id="male" name="gender" value="male" required> Male
                <input type="radio" id="female" name="gender" value="female" required> Female
            </div>
            <div class="form-group">
                <label for="proofOfBirth">Proof of Birth (Hospital Record, Max 50KB):</label>
                <input type="file" id="proofOfBirth" name="proofOfBirth" required accept=".pdf,.doc,.docx">
            </div>
            
            <h2>Parent's Information</h2>
            <div class="form-group">
                <label for="motherName">Mother's Full Name:</label>
                <input type="text" id="motherName" name="motherName" required>
            </div>
            <div class="form-group">
                <label for="fatherName">Father's Full Name:</label>
                <input type="text" id="fatherName" name="fatherName" required>
            </div>
            <div class="form-group">
                <label for="parentAadhar">Parents' Aadhar Number (12 digits):</label>
                <input type="text" id="parentAadhar" name="parentAadhar" required pattern="[0-9]{12}">
            </div>

            <h2>Additional Information</h2>
            <div class="form-group">
                <label for="parentID">Parent's Identification (Max 50KB):</label>
                <input type="file" id="parentID" name="parentID[]" multiple required accept=".pdf,.doc,.docx">
            </div>
            <div class="form-group">
                <label for="maritalStatus">Marital Status of Parents:</label>
                <input type="text" id="maritalStatus" name="maritalStatus" required>
            </div>

            <h2>Parent's Contact Information</h2>
            <div class="form-group">
                <label for="address">Address (e.g., Mandal, District, State):</label>
                <input type="text" id="address" name="address" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number (10 digits):</label>
                <input type="tel" id="phone" name="phone" required pattern="[0-9]{10}">
            </div>
            <div class="form-group">
                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$">
            </div>
            <div class="form-group">
                <label for="witnessInfo">Witness Information (if any):</label>
                <input type="text" id="witnessInfo" name="witnessInfo">
            </div>
            <!-- Your form fields -->
            <button onclick="pay()" type="submit">Submit & Pay (Application Fee 25/-)</button>
        </form>

        <script>
            function pay() {
                alert("Payment Successful!");
                window.location.href = "registration_success.php"; // Redirect to registration success page
            }
        </script>
    </div>
</body>
</html>
