<?php
session_start();

// Check if admin is logged in, redirect to login page if not
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch application details by ID
$id = $_POST['id'];
$sql = "SELECT * FROM applications WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Include TCPDF library
    require_once(__DIR__ . '/tcpdf/tcpdf.php');

    // Create PDF instance
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('BirthCertify');
    $pdf->SetTitle('Birth Certificate');
    $pdf->SetSubject('Birth Certificate');

    // Add a page
    $pdf->AddPage();

    // Set font
    $pdf->SetFont('helvetica', '', 12);

    // Check if optional fields are set, else set to an empty string
    $registration_number = isset($row['registration_number']) ? htmlspecialchars($row['registration_number']) : '';
    $date_of_registration = isset($row['date_of_registration']) ? htmlspecialchars($row['date_of_registration']) : '';

    // Add content to the PDF
    $html = "
    <style>
        /* CSS styles here */
    </style>

    <div class='container'>
        <div class='header'>
            <img src='https://i.pinimg.com/originals/b1/7d/23/b17d2311f823936b4b0649db9abe5983.png' alt='Government of India Emblem'>
            <h1>Government of India</h1>
            <h2>Birth Certificate</h2>
        </div>
        
        <div class='content'>
            <p>This is to certify that the following information has been taken from the original record of birth which is the register for (Local Area)</p>
            <p>
                Place of Birth: <span class='blank'>" . htmlspecialchars($row['birth_place']) . "</span><br>
            </p>
            
            <table class='table-container'>
                <tr>
                    <th>Name</th>
                    <td><span class='blank'>" . htmlspecialchars($row['child_name']) . "</span></td>
                </tr>
                <tr>
                    <th>Sex</th>
                    <td><span class='blank'>" . htmlspecialchars($row['gender']) . "</span></td>
                </tr>
                <tr>
                    <th>Date of Birth</th>
                    <td><span class='blank'>" . htmlspecialchars($row['birth_date']) . "</span></td>
                </tr>
                <tr>
                    <th>Place of Birth</th>
                    <td><span class='blank'>" . htmlspecialchars($row['birth_place']) . "</span></td>
                </tr>
                <tr>
                    <th>Name of Father</th>
                    <td><span class='blank'>" . htmlspecialchars($row['father_name']) . "</span></td>
                </tr>
                <tr>
                    <th>Name of Mother</th>
                    <td><span class='blank'>" . htmlspecialchars($row['mother_name']) . "</span></td>
                </tr>
            </table>

            <p>
                Registration No.: <span class='blank'>" . $id . "</span><br>
            </p>
        </div>

        <div class='footer'>
            <p>This is to certify that the above information is true and correct to the best of my knowledge.</p>
            <p class='signature'>
                Signature of Issuing Authority: Government Of India
                <span></span>
            </p>
        </div>
    </div>";

    $pdf->writeHTML($html, true, false, true, false, '');

    // Output the PDF as a download
    $pdf->Output('birth_certificate.pdf', 'D');
} else {
    echo "Record not found.";
}

$stmt->close();
$conn->close();
?>
