<?php
session_start();

// Check if admin is logged in, redirect to login page if not
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch rejected registrations
$sql = "SELECT * FROM applications WHERE status = 'Rejected'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Rejected Registrations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #bebebe;
            margin-top: 20px;
            background-color: #fff; /* Added background color for the table */
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        .home-button {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
        .home-button a {
            padding: 10px 20px;
            background-color: #5cb85c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .home-button a:hover {
            background-color: #4cae4c;
        }
        .head {
            color: #A52A2A;
        }
    </style>
</head>
<body>
    <h1 class="head">Rejected Registrations</h1>
    <table>
        <tr>
            <th>Child's Name</th>
            <th>Date of Birth</th>
            <th>Mother's Full Name</th>
            <th>Father's Full Name</th>
            <th>Parent's Aadhar Number</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>Email Address</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row["child_name"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["birth_date"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["mother_name"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["father_name"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["parent_aadhar"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["address"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["phone"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='8'>No rejected registrations</td></tr>";
        }
        ?>
    </table>
    <div class="home-button">
        <a href="admin_home.php">Home</a>
    </div>
</body>
</html>

<?php
$conn->close();
?>
