<?php
session_start();

// Check if admin is logged in, redirect to login page if not
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "birth_certification";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch accepted registrations
$sql = "SELECT * FROM applications WHERE status = 'Accepted'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Accepted Registrations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        .view-button {
            padding: 6px 12px;
            background-color: #5cb85c;
            color: #fff;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .view-button:hover {
            background-color: #5cb85c;
        }
        .home-button {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
        .home-button a {
            padding: 10px 20px;
            background-color: #5cb85c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .home-button a:hover {
            background-color: #5cb85c;
        }
        .head {
            color: #5cb85c;
        }
    </style>
</head>
<body>
    <h1 class="head">Verified Applications</h1>
    <table>
        <tr>
            <th>Child's Name</th>
            <th>Date of Birth</th>
            <th>Mother's Full Name</th>
            <th>Father's Full Name</th>
            <th>Parent's Aadhar Number</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>Email Address</th>
            <th>Action</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["child_name"] . "</td>";
                echo "<td>" . $row["birth_date"] . "</td>";
                echo "<td>" . $row["mother_name"] . "</td>";
                echo "<td>" . $row["father_name"] . "</td>";
                echo "<td>" . $row["parent_aadhar"] . "</td>";
                echo "<td>" . $row["address"] . "</td>";
                echo "<td>" . $row["phone"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td><form action='generate_pdf.php' method='post'><input type='hidden' name='id' value='" . $row["id"] . "'><button class='view-button' type='submit'>View</button></form></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='9'>No accepted registrations</td></tr>";
        }
        ?>
    </table>
    <div class="home-button">
        <a href="admin_home.php">Home</a>
    </div>
</body>
</html>

<?php
$conn->close();
?>